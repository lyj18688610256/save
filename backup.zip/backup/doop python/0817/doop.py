#! /usr/bin/python3 python3
import time
import subprocess
import os
import sys

def cmd(command):
    subp = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding="utf-8",universal_newlines=True)
#    subp.wait(3600)   如果调用了该句,就不会实时打印出调试信息
    while True:
        nextline = subp.stdout.readline()
        if nextline == '' and subp.poll() is not None:  #subp.poll()为None时,表示进程正在运行
            break
        sys.stdout.write(nextline)
        sys.stdout.flush()
    if subp.poll() == 0:
        str='/home/lee/Documents/doop/downloads/out/securibench7/database'
        size = os.path.getsize('{mstr}/C.csv'.format(mstr=str))
        if size == 0:
            print('\n\n\n\n')
            print('--------')
            print('路径是空的')
            print('\n\n\n\n')
        else:
            str1='sed \'s/\]//g\' {mstr}/C.csv |sed \'s/\[//g\'|sed \'s/nil,//g\'|sed \'s/, </ -> </g\'|sed \'s/^/"/g\'|sed \'s/$/";/g\' |sed \'1i\strict digraph{{ \'|sed \'s/ -> /" -> "/g\' > {mstr}/F.dot'.format(mstr=str)
            str2='echo \'}}\' >> {mstr}/F.dot'.format(mstr=str)
            str3='dot -Tsvg {mstr}/F.dot -o {mstr}/output2.svg'.format(mstr=str)
            str4='xdg-open {mstr}/output2.svg'.format(mstr=str)
            os.system(str1)
            os.system(str2)
            os.system(str3)
            os.system(str4) 
    else:
        print("失败")

str_doop='/home/lee/Documents/doop/downloads'
str_input='/home/lee/Documents/doop/test34/securibench7.jar'
str_ID='securibench7'
str_cmd='cd {mstr_doop}; ./doop  -a micro  --input-file {mstr_input} --platform java_8_mini  --id {mstr_ID} --generate-jimple'.format(mstr_doop=str_doop,mstr_input=str_input,mstr_ID=str_ID)
cmd(str_cmd)
