package securibench.micro.aliasing;
import java.io.IOException;
import securibench.micro.*;
import securibench.micro.sanitizers.Sanitizers1;
public class aliasing_Harness {

	public void show(A mA1,B mB1) throws IOException {
		// TODO Auto-generated method stub
		//(new Sanitizers1()).doGet(mA, mB);
		(new Aliasing1()).doGet(mA1, mB1);
		(new Aliasing2()).doGet(mA1, mB1);
		(new Aliasing3()).doGet(mA1, mB1);
		(new Aliasing4()).doGet(mA1, mB1);
		(new Aliasing5()).doGet(mA1, mB1);
		(new Aliasing6()).doGet(mA1, mB1);
	}
}
