package securibench.micro.basic;
import java.io.IOException;
import securibench.micro.*;
public class basic_Harness{

	public void show(A mA1,B mB1) throws IOException {
		//(new Sanitizers1()).doGet(mA, mB);
		(new Basic1()).doGet(mA1, mB1);
		(new Basic2()).doGet(mA1, mB1);
		(new Basic3()).doGet(mA1, mB1);
		(new Basic4()).doGet(mA1, mB1);
		(new Basic5()).doGet(mA1, mB1);
		(new Basic6()).doGet(mA1, mB1);
		(new Basic7()).doGet(mA1, mB1);
		(new Basic8()).doGet(mA1, mB1);
		(new Basic9()).doGet(mA1, mB1);
		(new Basic10()).doGet(mA1, mB1);
		(new Basic11()).doGet(mA1, mB1);
		(new Basic12()).doGet(mA1, mB1);
		(new Basic13()).doGet(mA1, mB1);
		(new Basic14()).doGet(mA1, mB1);
		(new Basic15()).doGet(mA1, mB1);
		(new Basic16()).doGet(mA1, mB1);
		(new Basic17()).doGet(mA1, mB1);
		(new Basic18()).doGet(mA1, mB1);
		(new Basic19()).doGet(mA1, mB1);
		(new Basic20()).doGet(mA1, mB1);
		(new Basic21()).doGet(mA1, mB1);
		(new Basic22()).doGet(mA1, mB1);
		(new Basic23()).doGet(mA1, mB1);
		(new Basic24()).doGet(mA1, mB1);
		(new Basic25()).doGet(mA1, mB1);
		(new Basic26()).doGet(mA1, mB1);
		(new Basic27()).doGet(mA1, mB1);
		(new Basic28()).doGet(mA1, mB1);
		(new Basic29()).doGet(mA1, mB1);
		(new Basic30()).doGet(mA1, mB1);
		(new Basic31()).doGet(mA1, mB1);
		(new Basic32()).doGet(mA1, mB1);
		(new Basic33()).doGet(mA1, mB1);
		(new Basic34()).doGet(mA1, mB1);
		(new Basic35()).doGet(mA1, mB1);
		(new Basic36()).doGet(mA1, mB1);
		(new Basic37()).doGet(mA1, mB1);
		(new Basic38()).doGet(mA1, mB1);
		(new Basic39()).doGet(mA1, mB1);
		(new Basic40()).doGet(mA1, mB1);
		(new Basic41()).doGet(mA1, mB1);
		(new Basic42()).doGet(mA1, mB1);
		
	}
}
