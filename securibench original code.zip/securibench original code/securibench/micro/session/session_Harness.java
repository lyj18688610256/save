package securibench.micro.session;
import java.io.IOException;
import securibench.micro.*;
public class session_Harness{

	public void show(A mA1,B mB1) throws IOException {
		//(new Sanitizers1()).doGet(mA, mB);
		(new Session1()).doGet(mA1, mB1);
		(new Session2()).doGet(mA1, mB1);
		(new Session3()).doGet(mA1, mB1);
		
	}
}
