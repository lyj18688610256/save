package securibench.micro;
import securibench.micro.aliasing.*;
import securibench.micro.arrays.*;
import java.io.IOException;
import securibench.micro.*;
public class Harness {

	public static void main(String[] args)throws IOException  {
		// TODO Auto-generated method stub
		A mA1=new A();
		B mB1=new B();
		//(new Sanitizers1()).doGet(mA, mB);
		(new aliasing_Harness()).show();
		(new arrays_Harness()).show();
	}
}
